
package net.stonebomb.donutz.item;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.Food;

public class PRingCaramelItem extends Item {
	public PRingCaramelItem() {
		super(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16).rarity(Rarity.COMMON).food((new Food.Builder()).hunger(7).saturation(0.7f).build()));
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 56;
	}
}
