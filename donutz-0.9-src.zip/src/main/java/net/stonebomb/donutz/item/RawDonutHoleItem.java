
package net.stonebomb.donutz.item;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;

public class RawDonutHoleItem extends Item {
	public RawDonutHoleItem() {
		super(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16).rarity(Rarity.COMMON));
	}
}
