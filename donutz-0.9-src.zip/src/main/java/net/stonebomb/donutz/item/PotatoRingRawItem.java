
package net.stonebomb.donutz.item;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;

public class PotatoRingRawItem extends Item {
	public PotatoRingRawItem() {
		super(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16).rarity(Rarity.COMMON));
	}
}
