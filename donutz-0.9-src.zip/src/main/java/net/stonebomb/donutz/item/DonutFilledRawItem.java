
package net.stonebomb.donutz.item;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;

public class DonutFilledRawItem extends Item {
	public DonutFilledRawItem() {
		super(new Item.Properties().group(ItemGroup.FOOD).maxStackSize(16).rarity(Rarity.COMMON));
	}
}
